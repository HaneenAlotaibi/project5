import { Injectable } from '@angular/core';
export class FoodService {

  constructor() { }
  getAll():string[]{
    return[
      '/assets/food-1.jpg',
      '/assets/food-2.jpg',
      '/assets/food-3.jpg',
      '/assets/food-4.jpg',
      '/assets/food-5.jpg',
      '/assets/food-6.jpg' 
]
}
}

//      { id:1,
//       price:5,
//       name:'Brassica',
//       tags:['Brassica'],
//       imageUrl:'/assets/food-1.jpg',
//   origins:['Kuwait']},
//   { id:2,
//     price:2,
//     name:'Capsicum',
// tags:['Capsicum'],
// imageUrl:'/assets/food-2.jpg',
// origins:['Kuwait']},
// { id:3,
//   price:7,
//   name:'Cucumis sativus',
// tags:['Cucumis sativus'],
// imageUrl:'/assets/food-3.jpg',
// origins:['Kuwait']},
// { id:4,
//   price:3,
//   name:'carrot',
// tags:['carrot'],
// imageUrl:'/assets/food-4.jpg',
// origins:['Kuwait']},
// { id:5,
// price:2,
// name:'Pastinaca sativa',
// tags:['Pastinaca sativa'],
// imageUrl:'/assets/food-5.jpg',
// origins:['Kuwait']},
// { id:6,
// price:4,
// name:'tomato',
// tags:['tomato'],
// imageUrl:'/assets/food-6.jpg',
// origins:['Kuwait']}
