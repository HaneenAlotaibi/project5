import { Injectable } from '@angular/core';
import { Foods } from 'src/app/shared/models/food';

@Injectable({
  providedIn: 'root'
})
export class FoodtestService {

  constructor() { }
  getFoodById(id:number):Foods{
    return this.getAll().find(food =>food.id==id)!;

  }
  getAll():Foods[]{
    return[
      { id:1,
        price:5,
        name:'watermelon',
        tags:['watermelon'],
        imageUrl:'/assets/food-1.jpg',},
    { id:2,
      price:2,
      name:'Banana',
  tags:['Banana'],
  imageUrl:'/assets/food-2.jpg',},
  { id:3,
    price:7,
    name:'blackberry',
  tags:['blackberry'],
  imageUrl:'/assets/food-3.jpg',
 },
  { id:4,
    price:3,
    name:'nectarines',
  tags:['nectarines'],
  imageUrl:'/assets/food-4.jpg',
  },
  { id:5,
  price:2,
  name:'lemon',
  tags:['lemon'],
  imageUrl:'/assets/food-5.jpg',
  },
  { id:6,
  price:4,
  name:'Dragon',
  tags:['Dragon'],
  imageUrl:'/assets/food-6.jpg',
}
  
  
  
]
}
}

