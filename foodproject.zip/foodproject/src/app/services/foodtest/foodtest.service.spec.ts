import { TestBed } from '@angular/core/testing';

import { FoodtestService } from './foodtest.service';

describe('FoodtestService', () => {
  let service: FoodtestService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(FoodtestService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
