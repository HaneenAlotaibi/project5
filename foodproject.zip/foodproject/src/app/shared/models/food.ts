export class Foods{
    id!:number;
    price!:number;
    name!:string;
    tags?:string[];
    imageUrl!:string;
    
}