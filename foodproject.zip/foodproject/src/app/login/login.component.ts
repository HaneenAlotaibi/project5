import { Component } from '@angular/core';
import { ActivatedRoute, Route, Router } from '@angular/router';
@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent {
constructor(private router:Router){}
login(){
  this.router.navigateByUrl('')
}
changepassword(){
  this.router.navigateByUrl('changepassword')
} 
}

