import { Component, OnInit } from '@angular/core';
import { CartService } from '../services/cart.service';
import { FoodtestService } from '../services/foodtest/foodtest.service';
import { Cart } from '../shared/models/Cart';
import { cartItem } from '../shared/models/cartItem';
import { ActivatedRoute, Route, Router } from '@angular/router';
@Component({
  selector: 'app-cart-page',
  templateUrl: './cart-page.component.html',
  styleUrls: ['./cart-page.component.css']
})
export class CartPageComponent implements OnInit {
cart!: Cart;
constructor(private cartService:CartService,private router:Router){
  // constructor(private cartService:CartService,private foodService:FoodtestService){

  // let foods=foodService.getAll();
  // cartService.addToCart(foods[1]);
  this.setCart();
}
ngOnInit(): void {

}
setCart(){
  this.cart=this.cartService.getCart();
}
removeFromCart(cartIteme: cartItem){
this.cartService.removeFromCart(cartIteme.food.id);
this.setCart();
}
changeQuantity(cartItem1:cartItem,quantityInString:string){
  const quantity=parseInt(quantityInString);
  this.cartService.changeQuantiy(cartItem1.food.id,quantity);
  this.setCart();
}
payment(){
  this.router.navigateByUrl('payment')
} 
}
