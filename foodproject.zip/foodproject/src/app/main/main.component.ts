import { Food1Service } from '../services/food1/food1.service';
import { Component, OnInit } from '@angular/core';
import { ActivatedRoute } from '@angular/router';
import { __param } from 'tslib';

@Component({
  selector: 'app-main',
  templateUrl: './main.component.html',
  styleUrls: ['./main.component.css']
})
export class MainComponent implements OnInit{
  foods:string[]=[];
  foodsname:string[]=[];
  constructor(private fs:Food1Service, private router:ActivatedRoute){}
ngOnInit():void{
  this.foods=this.fs.getAll();
 this.foodsname=this.fs.getAll1();
}
}
